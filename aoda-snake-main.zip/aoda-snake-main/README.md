# aoda-snake | Snake Game

## You can visit this project

* [Aoda Snake Game App - Initial Version](https://adityarizqi7.github.io/aoda-snake/)
* [Aoda Snake Game App - Latest Version](https://adityarizqi7.github.io/aoda-snake/)

[![Netlify Status](https://api.netlify.com/api/v1/badges/2da969bf-4a29-476b-b776-d545c6af0feb/deploy-status)](https://app.netlify.com/sites/aoda-snake/deploys)
